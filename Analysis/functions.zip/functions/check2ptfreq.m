function out = check2ptfreq(f1, f2, f12)
    
    tol=5;
    f1 = round(f1, tol);
    f2 = round(f2, tol);
    f12 = round(f12, tol);
    
    maxfreq = min(f1, f2);
    
    if( (f1+f2) <= 1 )
       minfreq = 0;     
    end
    
    if( (f1+f2) > 1 )
       minfreq = (f1+f2)-1;     
    end
    
    out = ( (f12>=minfreq) & (f12<=maxfreq) );
    
end