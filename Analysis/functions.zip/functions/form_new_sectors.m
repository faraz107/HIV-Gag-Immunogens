function [sec_eig, sec_eig_true, sec_eig_incl_cs, length_sec, alpha] = ...
    form_new_sectors(sec_eig_old, sec_eig_true_old, sec_eig_incl_cs_old, length_sec_old, alpha_old)

alpha = 7;

i=1;j=1;
sec_eig{1, j}           = sec_eig_old{1, i};
sec_eig_true{1, j}      = sec_eig_true_old{1, i};
sec_eig_incl_cs{1, j}   = sec_eig_incl_cs_old{1, i};
length_sec(j)           = length_sec_old(i);

i=2;j=2;
sec_eig{1, j}           = sec_eig_old{1, i};
sec_eig_true{1, j}      = sec_eig_true_old{1, i};
sec_eig_incl_cs{1, j}   = sec_eig_incl_cs_old{1, i};
length_sec(j)           = length_sec_old(i);

i=3;j=3;
sec_eig{1, j}           = union(sec_eig_old{1, i}, sec_eig_old{1, 7});
sec_eig_true{1, j}      = union(sec_eig_true_old{1, i}, sec_eig_true_old{1, 7});
sec_eig_incl_cs{1, j}   = union(sec_eig_incl_cs_old{1, i}, sec_eig_incl_cs_old{1, 7});
length_sec(j)           = length_sec_old(i) + length_sec_old(7);

i=4;j=4;
sec_eig{1, j}           = sec_eig_old{1, i};
sec_eig_true{1, j}      = sec_eig_true_old{1, i};
sec_eig_incl_cs{1, j}   = sec_eig_incl_cs_old{1, i};
length_sec(j)           = length_sec_old(i);

i=5;j=5;
sec_eig{1, j}           = sec_eig_old{1, i};
sec_eig_true{1, j}      = sec_eig_true_old{1, i};
sec_eig_incl_cs{1, j}   = sec_eig_incl_cs_old{1, i};
length_sec(j)           = length_sec_old(i);

i=6;j=6;
sec_eig{1, j}           = union(sec_eig_old{1, i}, sec_eig_old{1, 9});
sec_eig_true{1, j}      = union(sec_eig_true_old{1, i}, sec_eig_true_old{1, 9});
sec_eig_incl_cs{1, j}   = union(sec_eig_incl_cs_old{1, i}, sec_eig_incl_cs_old{1, 9});
length_sec(j)           = length_sec_old(i) + length_sec_old(9);

i=8;j=7;
sec_eig{1, j}           = sec_eig_old{1, i};
sec_eig_true{1, j}      = sec_eig_true_old{1, i};
sec_eig_incl_cs{1, j}   = sec_eig_incl_cs_old{1, i};
length_sec(j)           = length_sec_old(i);


end