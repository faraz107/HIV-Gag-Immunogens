function Y = plotHist(X, numBins)

if(numBins==0)   
Y = histogram(X, 'normalization', 'pdf');
else
bw = (max(X)-min(X))/numBins;
Y = histogram(X, 'normalization', 'pdf', 'BinWidth', bw);
end

end