function [msa_without_phylogeny,lambda] = remove_phylogeny(msa_bin)

% Code to remove the phylogenetic effects from the input MSA
%
% Written by: Ahmed Abdul Quadeer
% Last updated: 2017-03-25
%
% INPUT
%     msa_bin                   N-by-M binarized MSA
%
% OUTPUT
%     msa_without_phylogeny     MSA with effect of phylogeny potentially
%                               removed
%     lambda                    Eigenvalues of the MSA without phylogeny

%%
[~,M] = size(msa_bin);

% for kk = 1:M
%     msa_bin(:,kk) = (msa_bin(:,kk)-mean(msa_bin(:,kk)))/sqrt(var(msa_bin(:,kk)));
% end

C = corrcoef(msa_bin);
Q = eig_sort(C);
q_1 = Q(:,1);
proj_1 = msa_bin*q_1;

for k = 1:M
    b = msa_bin(:,k);
    probs_01 = mnrval(mnrfit(proj_1,b+1),proj_1);
    %because mnrfit requires greater than 1 in second
    %argument --- two categories 1 and 2
    X(:,k) = probs_01(:,2);
end

msa_without_phylogeny = msa_bin - X;
C_without_phylogeny = corrcoef(msa_without_phylogeny);



[~,lambda] = eig_sort(C_without_phylogeny);