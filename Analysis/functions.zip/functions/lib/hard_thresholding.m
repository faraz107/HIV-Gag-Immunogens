function [value_after_thresh] = hard_thresholding(x,t)

n = length(x);
value_after_thresh = zeros(1,n);
for i = 1:n 
	if x(i) >= t
	  value_after_thresh(i) = x(i);
	elseif x(i) <= -t
	  value_after_thresh(i) = x(i);
	else value_after_thresh(i) = 0;
	end
end