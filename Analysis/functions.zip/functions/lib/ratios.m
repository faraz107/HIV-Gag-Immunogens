function [ratioP_out,ratioN_out] = ratios(p,P)

if nargin == 2
    N = p-P;
    ratioP_out = (P*(P-1)+N*(N-1))/p/(p-1);
    ratioN_out = 2*P*N/p/(p-1);
end

if nargin == 1

    disp('Number of positive entries not specified.')
    disp('Plotting all possible ratios as a function of the number of positive entries...')
    ratioP_out = 1;
    ratioN_out = 0;
    
    x=0:p;
    plot(x, (x.*(x-1)+(p-x).*(p-x-1))/p/(p-1))
    hold on
    plot(x, 2*x.*(p-x)/p/(p-1),'r')

end

end

