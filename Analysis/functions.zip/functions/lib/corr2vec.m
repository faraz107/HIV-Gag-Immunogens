function [vec] = corr2vec(A)

% Returns a vector with the upper off-diagonal elements of the squared matrix A

p = size(A,1);
vec = zeros(p*(p-1)/2,1);
count = 1;
for ii=1:p
    for jj=ii+1:p
       vec(count) = A(ii,jj);
       count = count+1;
    end
end

end




