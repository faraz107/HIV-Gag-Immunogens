function [y] = upTVec(X)

y = X(~tril(ones(size(X))));

end