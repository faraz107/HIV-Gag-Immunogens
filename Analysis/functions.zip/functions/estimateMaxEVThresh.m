function [E] = estimateMaxEVThresh(numRndRuns, MSA_binary)

[N_seq, N_pos_bin]=size(MSA_binary);

bin_msa = MSA_binary;

max_eVal_bin_rnd = zeros(1, numRndRuns);
eVal_bin_rnd = zeros(N_pos_bin, numRndRuns);
ipr = zeros(N_pos_bin, numRndRuns);

for k=1:numRndRuns
    k
    test_msa = zeros(N_seq, N_pos_bin);
    
    for i=1:N_pos_bin
        test_msa(:, i) = bin_msa(randperm(N_seq), i);
    end

    X=test_msa;
    for kk = 1:N_pos_bin
        X(:,kk) = (X(:,kk)-mean(X(:,kk)))/sqrt(var(X(:,kk)));
    end
    test_msa=X;
    
    test_bin = corr(test_msa);
    test_bin(eye(N_pos_bin)==1) = 1;
    
    U=[]; V=[]; a=[]; b=[];
    [U, V] = eig(test_bin);
    max_eVal_bin_rnd(:, k) = max(diag(V));
    
    bin_msa = test_msa;
    
    [a b] = sort(diag(V), 'ascend');
    U = U(:, b);
    evl = diag(V);    
    eVal_bin_rnd(:, k) = evl(b);
    
%     eVec_bin_rnd(:, :, k) = U;

        for i=1:N_pos_bin
        ipr(i, k) = ( sum(U(:,i).^4) );
        end

end

% Outputs

E.maxeVal_bin_rnd = max_eVal_bin_rnd;
E.eVal_bin_rnd = eVal_bin_rnd;
% E.eVec_bin_rnd = eVec_bin_rnd;
E.ipr = ipr;

end